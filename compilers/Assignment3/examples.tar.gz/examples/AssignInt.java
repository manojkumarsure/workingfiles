class AssignInt
{
	public static void main(String[] args)
	{
		System.out.println(new Test().foo(10, 11));
	}
}

class Test
{
	public int foo(int num, int num2)
	{
		int x;
		int y;
		x = 10;
		y = 7;
		num = x + y;
		return num;
	}
}
