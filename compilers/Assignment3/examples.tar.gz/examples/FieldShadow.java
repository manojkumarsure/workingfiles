class FieldShadow {
    public static void main(String[] a){
            System.out.println(new Test().foo(5));
        }
}

class Parent
{
	boolean x;
}


class Test extends Parent{
	int x;
    public int foo(int num){
            Parent p;
            if(x<0)
            {
            }
            else
            {
            }
            return 5;
        }
}

