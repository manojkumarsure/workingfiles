class SimpleIf{
    public static void main(String[] a){
        System.out.println(new Test().foo(false));
    }
}


class Test {
    public int foo(boolean flg) {
        if(flg){
	}
	else
	{
	}
	return 33;
    }
}
