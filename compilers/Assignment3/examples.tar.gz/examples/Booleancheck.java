class Booleancheck {
  public static void main(String[] a){
    System.out.println(new Test().foo());
  }
}

class Test {
  public int foo() {
    boolean isHead;
    isHead = true;
    if(isHead)
    {
    	isHead = true;
    }
    
    else
    {
    	isHead = true;
    }
     
     return 0;
  }
}
