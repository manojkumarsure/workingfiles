conflict(cs1100, cs6843).
conflict(cs6843, cs4240).
