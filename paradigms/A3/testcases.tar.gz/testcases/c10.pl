conflict(cs6843, cs4240).
conflict(cs4240, cs1200).
conflict(cs1200, cs3100).
conflict(cs3100, cs4240).
conflict(cs3100, cs1100).
conflict(cs4240, cs1100).
conflict(cs4240, cs2100).


