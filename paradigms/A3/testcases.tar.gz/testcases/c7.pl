conflict(cs1100, cs6843).
conflict(cs1100, cs4240).

