Writer2LaTeX version 1.2.1
==========================

This is the distribution of Writer2LaTeX version 1.2.1

Latest version can be found at the web site
  http://writer2latex.sourceforge.net
  
You can read about installation and usage of Writer2LaTeX
in the user guide, which is included in the
directory doc.
  
Bugs and feature requests should be reported to
  writer2latex (at) gmail.com
  

September 2014
Henrik Just
